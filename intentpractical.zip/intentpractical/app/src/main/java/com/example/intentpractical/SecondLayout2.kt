package com.example.intentpractical

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondLayout2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_layout2)
        val display=findViewById<TextView>(R.id.display)
        display.setText(intent.extras!!.getString("msg"))
    }
}