package com.example.practical4listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sub= arrayOf<String>("CandyCrush","Pubg","Fruitcrush","Sudoku","bgmi","CS:GO","Temple Run","Subway Surfer","Ashpalt","racing")
        val lview=findViewById<ListView>(R.id.my_list)
        lview.adapter=ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,sub)
        lview.setOnItemClickListener{parent,view,position,id->val toast= Toast.makeText(this,"You have selected a game\n"+sub[position],
        Toast.LENGTH_LONG)
            toast.show()
            toast.setGravity(Gravity.CENTER,0,0)
            toast.show()
            }
    }
}