package com.studentmanagmentproject.studentmanagement;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.studentmanagemnetsysytem.student.repository.StudentRepository;


@SpringBootTest
class StudentmanagementApplicationTests {

	

}
		

