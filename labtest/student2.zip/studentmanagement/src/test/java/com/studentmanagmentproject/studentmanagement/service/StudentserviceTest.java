package com.studentmanagmentproject.studentmanagement.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.studentmanagemnetsysytem.student.repository.StudentRepository;
import com.studentmanagmentproject.studentmanagement.entity.Student;

class StudentserviceTest {
	private StudentRepository srr;
	private Studentservice ss;

	@Test
	void testAddstudent() {
		Student s1=new Student();
		s1.setSname("viral");
		s1.setSclass("java");
		s1.setMarks(50);
		srr.save(s1);
		Assertions.assertEquals(s1.getMarks(),50);
		
		
		
	}	


	
}
