package com.studentmanagmentproject.studentmanagement.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentmanagmentproject.studentmanagement.entity.Student;
import com.studentmanagmentproject.studentmanagement.service.Studentservice;

@RestController
@RequestMapping("/api/student")
public class StudentController {
	private Studentservice ss;
	
	public StudentController(Studentservice ss) {
		super();
		this.ss = ss;
	}

	@PostMapping()
	public ResponseEntity<Student> addstudent(@RequestBody Student s1) {
		return new ResponseEntity<Student>(ss.addstudent(s1),HttpStatus.CREATED);
	}
	@GetMapping
	public List<Student> getallstudent(){
		return ss.getallstudent();
		}
	
   @GetMapping("{sid}")
	public ResponseEntity<Student> Studentfindbyid(@PathVariable("sid") Long sid){
            return new ResponseEntity<Student>(ss.getstudentbyid(sid),HttpStatus.OK);
   }
   @PutMapping("{sid}")
   public ResponseEntity<Student> updatestudentbyid(@PathVariable("sid") Long sid,@RequestBody Student s){
	   return new ResponseEntity<Student>(ss.updatestudent(s,sid),HttpStatus.OK);
   }
   @DeleteMapping("{sid}")
   public ResponseEntity<String> deletestudentbyid(@PathVariable("sid")Long sid) {
	   ss.deletebyid(sid);
	   return new ResponseEntity<String>("record deleted!!!!",HttpStatus.OK);
   }
   @GetMapping("/result/{sid}")
   public ResponseEntity<String> resultfindingbyid(@PathVariable("sid") Long sid,@RequestBody Student s,String sname) {
        return new ResponseEntity<String>(ss.result(sname, s, sid),HttpStatus.OK);
}}
