package com.studentmanagmentproject.studentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentmanagmentproject.studentmanagement.entity.Student;

public interface Studentrepository extends JpaRepository<Student,Long>{

}
