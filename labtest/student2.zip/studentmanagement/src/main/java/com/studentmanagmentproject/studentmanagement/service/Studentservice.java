package com.studentmanagmentproject.studentmanagement.service;

import java.util.List;

import com.studentmanagmentproject.studentmanagement.entity.Student;

public interface Studentservice {
         public Student addstudent(Student s);
         public List<Student> getallstudent();
         public Student updatestudent(Student s,long sid);
         public Student getstudentbyid(long sid); 
         public void deletebyid(long sid);
         public String result(String sname,Student s,long sid);
}
