package com.studentmanagmentproject.studentmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.studentmanagmentproject.studentmanagement.entity.Student;
import com.studentmanagmentproject.studentmanagement.exception.StudentNotFoundException;
import com.studentmanagmentproject.studentmanagement.repository.Studentrepository;
@Service
public class Studentserviceimplement implements Studentservice{
	
     private Studentrepository sr;
    
	public Studentserviceimplement(Studentrepository sr) {
		super();
		this.sr = sr;
	}

	@Override
	public Student addstudent(Student s) {
		return sr.save(s);
	}

	@Override
	public List<Student> getallstudent() {
     return sr.findAll();
	}

	
	@Override
	public Student getstudentbyid(long sid) {
		return sr.findById(sid).orElseThrow(()->new StudentNotFoundException("Student","sid",sid));
	}

	@Override
	public Student updatestudent(Student s, long sid) {
		Student s1=sr.findById(sid).orElseThrow(()-> new StudentNotFoundException("Student","sid",sid));
		s1.setSname(s.getSname());
		s1.setSclass(s.getSclass());
		s1.setMarks(s.getMarks());
		sr.save(s1);
		return s1;
	}

	@Override
	public void deletebyid(long sid) {
		sr.findById(sid).orElseThrow(()-> new StudentNotFoundException("Student","sid",sid));
		sr.deleteById(sid);
	}



	@Override
	public String result(String sname, Student s, long sid) {
		sr.findById(sid);
		if(s.getMarks()>35) {
			return s.getSname()+" pass in exam";
		}
		else
		{
			return s.getSname()+" fail in exam";
		}
	}
	
	
	}
	
	


