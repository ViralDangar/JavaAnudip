package com.studentmanagmentproject.studentmanagement.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND)
public class StudentNotFoundException extends RuntimeException{
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Long sid;
      private String sname,sclass;
      private Long marks;
	public StudentNotFoundException(String sname, String sclass, Long marks) {
		super(String.format("%s not found by this %s",sname,sid));
		this.sid = sid;
		this.sname = sname;
		this.sclass = sclass;
		this.marks = marks;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Long getSid() {
		return sid;
	}
	public String getSname() {
		return sname;
	}
	public String getSclass() {
		return sclass;
	}
	public Long getMarks() {
		return marks;
	}
      
      
}