package com.studentmanagemnetsysytem.student.controller;

import com.studentmanagemnetsysytem.student.entity.Student;
import com.studentmanagemnetsysytem.student.service.Studentservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/main/student")
public class StudentController {

    private Studentservice ss;



    @PostMapping("/main/student/hello")
    public Student addsstudent(@RequestBody Student s){
         return ss.addstudent(s);
    }
}
