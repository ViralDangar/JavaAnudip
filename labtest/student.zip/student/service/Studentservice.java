package com.studentmanagemnetsysytem.student.service;

import com.studentmanagemnetsysytem.student.entity.Student;
import org.springframework.stereotype.Service;

import java.util.List;

public interface Studentservice {
    public Student addstudent(Student s);
    public List<Student> allstudent();
    public Student getbyid( long sid);
  //  public void update(Student s,double marks);
    public void deletebyid(Long sid);



}
