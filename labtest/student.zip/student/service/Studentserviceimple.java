package com.studentmanagemnetsysytem.student.service;

import com.studentmanagemnetsysytem.student.entity.Student;
import com.studentmanagemnetsysytem.student.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class Studentserviceimple implements Studentservice{
    

    private StudentRepository sr;
public Studentserviceimple(StudentRepository sr) {
    this.sr = sr;
}
    @Override
    public Student addstudent(Student s) {
        return sr.save(s);
    }

    @Override
    public List<Student> allstudent() {
        return (List<Student>)sr.findAll();
    }

    @Override
    public Student getbyid(long sid) {
        return sr.findById(sid).get();
    }

   // @Override
    //public void update(Student s, double marks) {
     //    sr.upda;
    //}

    @Override
    public void deletebyid(Long sid) {
        sr.deleteById(sid);
    }
}
