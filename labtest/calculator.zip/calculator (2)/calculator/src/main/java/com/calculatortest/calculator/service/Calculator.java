package com.calculatortest.calculator.service;

import org.springframework.stereotype.Service;

@Service
public interface Calculator {
	 int div(int x,int y);
	 int mul(int x,int y);
	 int add(int x,int y);
	 int sub(int x,int y);
	

}
