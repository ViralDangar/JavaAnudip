package com.calculatortest.calculator.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.calculatortest.calculator.service.Calcservice;
import com.calculatortest.calculator.service.Calculator;
import com.calculatortest.calculator.service.Calculatorimp;

@RestController
public class calcontroller {
	Calculator c=new Calculatorimp();
	@GetMapping("/div/{x}/{y}")
	public int div(@PathVariable("x")int x,@PathVariable("y") int y)
	{
		return c.div(x,y);
	}
	@GetMapping("/add/{x}/{y}")
	public int add(@PathVariable("x")int x,@PathVariable("y") int y)
	{
		return c.add(x,y);
	}
	@GetMapping("/mul/{x}/{y}")
	public int mul(@PathVariable("x")int x,@PathVariable("y") int y)
	{
		return c.mul(x,y);
	}
	@GetMapping("/sub/{x}/{y}")
	public int sub(@PathVariable("x")int x,@PathVariable("y") int y)
	{
		return c.sub(x,y);
	}
	

}
