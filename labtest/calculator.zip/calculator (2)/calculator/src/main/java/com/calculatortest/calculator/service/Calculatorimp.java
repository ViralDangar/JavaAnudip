package com.calculatortest.calculator.service;

import org.springframework.stereotype.Service;

@Service
public class Calculatorimp implements Calculator {
       public int div(int x,int y)
       {
    	   return x/y;
       }
       public int add(int x,int y)
       {
    	   return x+y;
       }
       public int sub(int x,int y)
       {
    	   return x-y;
       }
       public int mul(int x,int y)
       {
    	   return x*y;
       }
}
